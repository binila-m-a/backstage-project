import React from 'react';
export declare const searchPage: React.JSX.Element;
