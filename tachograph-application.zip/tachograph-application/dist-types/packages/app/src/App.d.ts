import React from 'react';
declare const _default: React.ComponentType<{
    children?: React.ReactNode;
}>;
export default _default;
